// ─────────────────────────────────────────────────────
//  CONFIGURA AQUÍ TU SORTEO
//  Edita este archivo y recarga el navegador.
// ─────────────────────────────────────────────────────
window.RAFFLE_CONFIG = {
  title: "Gran Sorteo 2026",

  // Duración del giro en milisegundos (3000–12000)
  spinDuration: 6000,

  // Lista de participantes
  // Opciones por participante:
  //   name:  (obligatorio) nombre visible
  //   image: (opcional) ruta a foto relativa a index.html, ej: "fotos/ana.jpg"
  //   color: (opcional) color forzado para ese segmento, ej: "#FF0000"
  participants: [
    { name: "Alejandro", image: "fotos/alejandro.svg" },
    { name: "Yago",      image: "fotos/yago.svg"      },
    { name: "Parris",    image: "fotos/parris.svg"    },
    { name: "Daniel",    image: "fotos/daniel.svg"    },
    { name: "Pablo",     image: "fotos/pablo.svg"     }
  ],

  // Paleta de colores (se cicla si hay más participantes que colores)
  colors: [
    "#E94560",
    "#0F3460",
    "#533483",
    "#2C7873",
    "#F5A623",
    "#7B2D8B",
    "#1A6B4A",
    "#C0392B",
    "#2980B9",
    "#8E44AD"
  ],

  // Sonido de tick al girar (usa Web Audio API, no requiere archivos)
  sound: true
};
